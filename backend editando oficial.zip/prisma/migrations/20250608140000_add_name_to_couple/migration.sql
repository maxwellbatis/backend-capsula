-- AlterTable
ALTER TABLE "Couple" ADD COLUMN "name" TEXT;
